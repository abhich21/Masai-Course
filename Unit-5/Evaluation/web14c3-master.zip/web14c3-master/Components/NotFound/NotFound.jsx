export const NotFound = () => {
  return (
    <div className="notFound">
      {/* Show some 404 not found image or component here */}
    </div>
  );
};
